public class Location {
  private int row;
  private int col;
}
