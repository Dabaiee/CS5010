public class PerfectMaze extends AbstractMaze {
  // seems not much to be put here, maybe just a constructor? It's up to you.
  // But it's good to have this hierarchical structure of different mazes for
}
