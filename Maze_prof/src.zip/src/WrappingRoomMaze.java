public class WrappingRoomMaze extends RoomMaze {

}
