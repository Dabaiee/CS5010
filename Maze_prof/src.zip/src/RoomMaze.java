public class RoomMaze extends AbstractMaze {
  // see the comment in PerfectMaze
}
