public enum MazeType {
    PERFECT_MAZE,
    ROOM_MAZE,
    WRAPPING_ROOM_MAZE
}
